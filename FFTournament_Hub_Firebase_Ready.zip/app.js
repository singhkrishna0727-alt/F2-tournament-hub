import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
  getFirestore, collection, getDocs, addDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const list = document.getElementById("tournaments");
const select = document.getElementById("tournament");
const form = document.getElementById("registrationForm");
const message = document.getElementById("message");

function prizeText(t) {
  const parts = [];
  if (t.prize1 != null) parts.push(`1st ₹${t.prize1}`);
  if (t.prize2 != null) parts.push(`2nd ₹${t.prize2}`);
  if (t.prize3 != null) parts.push(`3rd ₹${t.prize3}`);
  if (t.prize4to6 != null) parts.push(`4th–6th ₹${t.prize4to6}`);
  return parts.length ? parts.join(" • ") : (t.prize || "Prize details unavailable");
}

async function loadTournaments() {
  try {
    const snap = await getDocs(collection(db, "tournaments"));
    list.innerHTML = "";
    select.innerHTML = '<option value="">Select Tournament</option>';

    if (snap.empty) {
      list.innerHTML = "<p>No tournaments available.</p>";
      return;
    }

    snap.forEach(docSnap => {
      const t = docSnap.data();
      const card = document.createElement("div");
      card.className = "tournament";
      card.innerHTML = `
        <strong>${escapeHtml(t.name || "Tournament")}</strong>
        <div>Mode: ${escapeHtml(t.mode || "Solo")}</div>
        <div>Date: ${escapeHtml(t.date || "TBA")} • Time: ${escapeHtml(t.time || "TBA")}</div>
        <div>Slots: ${escapeHtml(String(t.slots ?? "TBA"))}</div>
        <div>Prizes: ${escapeHtml(prizeText(t))}</div>
      `;
      list.appendChild(card);

      const option = document.createElement("option");
      option.value = docSnap.id;
      option.textContent = t.name || docSnap.id;
      select.appendChild(option);
    });
  } catch (err) {
    console.error(err);
    list.innerHTML = "<p>Could not load tournaments. Check Firebase config and Firestore rules.</p>";
  }
}

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  message.textContent = "Submitting...";

  try {
    const tournamentId = select.value;
    if (!tournamentId) throw new Error("Select a tournament.");

    // No payment collection is included here.
    await addDoc(collection(db, "registrations"), {
      tournamentId,
      teamName: document.getElementById("teamName").value.trim(),
      captain: document.getElementById("captain").value.trim(),
      uid: document.getElementById("uid").value.trim(),
      createdAt: serverTimestamp()
    });

    message.textContent = "Registration submitted successfully.";
    form.reset();
  } catch (err) {
    console.error(err);
    message.textContent = err.message || "Registration failed.";
  }
});

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}

loadTournaments();
