import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
  getFirestore, collection, getDocs, addDoc, serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const form = document.getElementById("tournamentForm");
const registrations = document.getElementById("registrations");

form?.addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await addDoc(collection(db, "tournaments"), {
      name: document.getElementById("name").value.trim(),
      date: document.getElementById("date").value,
      mode: "Solo",
      entryFee: 0,
      prize: document.getElementById("prize").value.trim(),
      roomId: document.getElementById("roomId").value.trim(),
      createdAt: serverTimestamp()
    });
    alert("Tournament added.");
    form.reset();
  } catch (err) {
    console.error(err);
    alert("Could not add tournament. Check Firebase config and Firestore rules.");
  }
});

async function loadRegistrations() {
  try {
    const snap = await getDocs(collection(db, "registrations"));
    if (snap.empty) {
      registrations.textContent = "No registrations yet.";
      return;
    }
    registrations.innerHTML = "";
    snap.forEach(d => {
      const r = d.data();
      const row = document.createElement("div");
      row.className = "tournament";
      row.textContent = `${r.teamName || ""} — ${r.captain || ""} — UID: ${r.uid || ""} — Tournament: ${r.tournamentId || ""}`;
      registrations.appendChild(row);
    });
  } catch (err) {
    console.error(err);
    registrations.textContent = "Could not load registrations. Check Firebase config and Firestore rules.";
  }
}

loadRegistrations();
