import { initializeApp } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-app.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy } from "https://www.gstatic.com/firebasejs/12.3.0/firebase-firestore.js";
import { firebaseConfig } from "./firebase-config.js";

const app=initializeApp(firebaseConfig), db=getFirestore(app);

document.getElementById("tournamentForm").addEventListener("submit",async(e)=>{
 e.preventDefault();
 try{
  await addDoc(collection(db,"tournaments"),{
   name:name.value,date:date.value,entryFee:Number(entryFee.value),
   prize:prize.value,roomId:roomId.value
  });
  alert("Tournament added!");
  e.target.reset(); loadRegistrations();
 }catch(err){alert("Configure Firebase first.");}
});

async function loadRegistrations(){
 const box=document.getElementById("registrations");
 try{
  const snap=await getDocs(query(collection(db,"registrations"),orderBy("createdAt","desc")));
  box.innerHTML="";
  snap.forEach(d=>{
   const r=d.data();
   box.innerHTML += `<div class="tournament"><b>${r.teamName}</b> — ${r.captain}<br>UID: ${r.uid}<br>Phone: ${r.phone}<br>Tournament ID: ${r.tournament}</div>`;
  });
 }catch(e){box.textContent="Firebase is not configured yet.";}
}
loadRegistrations();